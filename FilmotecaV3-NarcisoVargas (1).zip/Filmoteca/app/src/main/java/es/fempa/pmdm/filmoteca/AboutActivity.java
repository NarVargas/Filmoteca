package es.fempa.pmdm.filmoteca;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);


    }

    public void btnWeb(View view) {
        startActivity(new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://naarvargas.000webhostapp.com/")));
    }

    public void btnSoporte(View view) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/html");
        intent.putExtra(Intent.EXTRA_EMAIL, "narvargasplay@gmail.com");
        intent.putExtra(Intent.EXTRA_SUBJECT, "");
        intent.putExtra(Intent.EXTRA_TEXT, "");

        startActivity(Intent.createChooser(intent, "Send Email"));
    }

    public void btnVolver(View view) {
        Intent intent2 = new Intent (view.getContext(), FilmListActivity.class);
        startActivityForResult(intent2, 0);
    }
}