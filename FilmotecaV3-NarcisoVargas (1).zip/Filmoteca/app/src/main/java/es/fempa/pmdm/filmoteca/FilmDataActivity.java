package es.fempa.pmdm.filmoteca;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class FilmDataActivity extends AppCompatActivity {
    public static String variable;
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        variable = getIntent().getExtras().getString("variable_string");
        setContentView(R.layout.activity_film_data);
        TextView textView = (TextView) findViewById(R.id.lblPeli);
        textView.setText(variable);

        if(variable.equals("Creed"))
        {
            ImageView caratula = findViewById(R.id.imagen);
            caratula.setImageResource(R.drawable.creed);
            TextView textView2 = (TextView) findViewById(R.id.director);
            textView2.setText("Director: Ryan Coogler");
            TextView textView3 = (TextView) findViewById(R.id.estreno);
            textView3.setText(R.string.estreno);
            TextView textView4 = (TextView) findViewById(R.id.genero);
            textView4.setText(R.string.genero);
            TextView textView5 = (TextView) findViewById(R.id.usuario);
            textView5.setText(R.string.cr);
        }
        else if(variable.equals("Avengers: Endgame"))
        {
            ImageView caratula = findViewById(R.id.imagen);
            caratula.setImageResource(R.drawable.avengers_endgame);
            TextView textView2 = (TextView) findViewById(R.id.director);
            textView2.setText("Director: Joe Russo");
            TextView textView3 = (TextView) findViewById(R.id.estreno);
            textView3.setText(R.string.estreno2);
            TextView textView4 = (TextView) findViewById(R.id.genero);
            textView4.setText(R.string.genero2);
            TextView textView5 = (TextView) findViewById(R.id.usuario);
            textView5.setText(R.string.veng);
        }
    }

    public void btnVolvInicio(View view)
    {
        Intent intent2 = new Intent (view.getContext(), FilmListActivity.class);
        startActivityForResult(intent2, 0);
    }

    public void editPeli(View view)
    {
        int LAUNCH_SECOND_ACTIVITY = 1;
        Intent i = new Intent(this, FilmEditActivity.class);
        startActivityForResult(i, LAUNCH_SECOND_ACTIVITY);
    }


    public void onBackPressed() {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

            if(resultCode == Activity.RESULT_OK){
                Toast toast1 = Toast.makeText(getApplicationContext(),
                                "✅", Toast.LENGTH_SHORT);

                toast1.show();
            }
            if (resultCode == Activity.RESULT_CANCELED) {
                Toast toast1 = Toast.makeText(getApplicationContext(),
                        "❌", Toast.LENGTH_SHORT);

                toast1.show();
            }

    }

    public void IMBD(View view)
    {
        if(variable.equals("Creed")) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.imdb.com/title/tt3076658/?ref_=nv_sr_srsg_3")));
        }
        else if(variable.equals("Vengadores: Endgame"))
        {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.imdb.com/title/tt4154796/?ref_=nv_sr_srsg_0" +
                            "")));
        }

    }
}