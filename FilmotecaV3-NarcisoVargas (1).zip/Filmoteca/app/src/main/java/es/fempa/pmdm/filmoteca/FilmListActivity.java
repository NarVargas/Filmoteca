package es.fempa.pmdm.filmoteca;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class FilmListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_film_list);
    }
    public void btnAcerca(View view)
    {
        Intent intent = new Intent (view.getContext(), AboutActivity.class);
        startActivityForResult(intent, 0);
    }

    public void btnPeliA(View view)
    {
        Intent intent = new Intent(this, FilmDataActivity.class);
        intent.putExtra("variable_string", "Avengers: Endgame");
        startActivity(intent);

    }

    public void btnPeliB(View view)
    {
        Intent intent = new Intent(this, FilmDataActivity.class);
        intent.putExtra("variable_string", "Creed");
        startActivity(intent);

    }
}