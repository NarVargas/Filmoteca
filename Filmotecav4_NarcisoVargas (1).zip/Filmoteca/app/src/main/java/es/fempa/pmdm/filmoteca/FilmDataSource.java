package es.fempa.pmdm.filmoteca;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;


public class FilmDataSource extends ArrayAdapter<Film> {

    public static List<Film> films;

    static {
        films = new ArrayList<Film>();

        Film f = new Film();
        f.title = "Regreso al futuro";
        f.director = "Robert Zemeckis";
        f.imageResId = R.mipmap.ic_launcher;
        f.comments = "";
        f.format = Film.FORMAT_DIGITAL;
        f.genre = Film.GENRE_SCIFI;
        f.imdbUrl = "http://www.imdb.com/title/tt0088763";
        f.year = 1985;

        films.add(f);

        f = new Film();
        f.title = "Regreso al futuro II";
        f.director = "Robert Zemeckis";
        f.imageResId = R.mipmap.ic_launcher;
        f.comments = "";
        f.format = Film.FORMAT_DIGITAL;
        f.genre = Film.GENRE_SCIFI;
        f.imdbUrl = "http://www.imdb.com/title/tt0096874";
        f.year = 1989;

        films.add(f);

        f = new Film();
        f.title = "Regreso al futuro III";
        f.director = "Robert Zemeckis";
        f.imageResId = R.mipmap.ic_launcher;
        f.comments = "";
        f.format = Film.FORMAT_DIGITAL;
        f.genre = Film.GENRE_SCIFI;
        f.imdbUrl = "http://www.imdb.com/title/tt0099088";
        f.year = 1990;

        films.add(f);

        f = new Film();
        f.title = "Los cazafantasmas";
        f.director = "Ivan Reitman";
        f.imageResId = R.mipmap.ic_launcher;
        f.comments = "";
        f.format = Film.FORMAT_DIGITAL;
        f.genre = Film.GENRE_COMEDY;
        f.imdbUrl = "http://www.imdb.com/title/tt0087332";
        f.year = 1984;

        films.add(f);

    }

    public FilmDataSource(@NonNull Context context, int resource, @NonNull List<Film> objects) {
        super(context, resource, objects);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        if(convertView==null){
            convertView = LayoutInflater.from(this.getContext()).inflate(R.layout.pelis, parent,false);
        }
        TextView titulo = (TextView)convertView.findViewById(R.id.titulo);
        TextView director = (TextView)convertView.findViewById(R.id.director);
        ImageView imagen = (ImageView)convertView.findViewById(R.id.imagen);

        Film l = getItem(position);

        titulo.setText(l.title);

        director.setText(l.director);

        imagen.setImageResource(l.imageResId);

        return convertView;
    }
}