package es.fempa.pmdm.filmoteca;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class FilmEditActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    String nombre = "";
    long i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.linear_layout);

        Intent intent = getIntent();
        i = intent.getExtras().getLong("Peli");
        Film f = FilmDataSource.films.get((int)i);
        String titulo = f.title;

        EditText textTitulo = (EditText) findViewById(R.id.titulo);
        textTitulo.setText(titulo);

        String director = f.director;

        EditText textDirector = (EditText) findViewById(R.id.director);
        textDirector.setText(director);

        String imbd = f.imdbUrl;

        EditText textIMBD = (EditText) findViewById(R.id.verIMDB);
        textIMBD.setText(imbd);

        String comentarios = f.comments;

        EditText textComent = (EditText) findViewById(R.id.comentarios);
        textComent.setText(comentarios);

        int año = f.year;
        String strAnyo = String.valueOf(año);
        EditText textAnyo = (EditText) findViewById(R.id.año);
        textAnyo.setText(strAnyo);


        Spinner spinner  = findViewById(R.id.spinner1);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.generos, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

        Spinner spinner2  = findViewById(R.id.spinner2);
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this,R.array.formato, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(adapter2);
        spinner2.setOnItemSelectedListener(this);

        ((Spinner)findViewById(R.id.spinner1)).setSelection(FilmDataSource.films.get((int) i).genre);
        ((Spinner)findViewById(R.id.spinner2)).setSelection(FilmDataSource.films.get((int) i).format);
    }

    public void guardar(View view)
    {
        EditText text = findViewById(R.id.director);
        String director = text.getText().toString();
        FilmDataSource.films.get((int)i).director = director;

        EditText text2 = findViewById(R.id.titulo);
        String titulo = text2.getText().toString();
        FilmDataSource.films.get((int)i).title = titulo;

        EditText text3 = findViewById(R.id.verIMDB);
        String IMBD = text3.getText().toString();
        FilmDataSource.films.get((int)i).imdbUrl = IMBD;

        EditText text4 = findViewById(R.id.comentarios);
        String comentarios = text4.getText().toString();
        FilmDataSource.films.get((int)i).comments = comentarios;

        EditText textAnyo = findViewById(R.id.año);
        String strAnyo = textAnyo.getText().toString();
        FilmDataSource.films.get((int) i).year = Integer.parseInt(strAnyo);

        FilmDataSource.films.get((int) i).genre = ((Spinner)findViewById(R.id.spinner1)).getSelectedItemPosition();
        FilmDataSource.films.get((int) i).format = ((Spinner)findViewById(R.id.spinner2)).getSelectedItemPosition();



        Intent intent = new Intent(this, FilmListActivity.class);
        startActivity(intent);


    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
        Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}