package es.fempa.pmdm.filmoteca;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class FilmDataActivity extends AppCompatActivity {
    public String nombre = "";
    public long i = 0;

    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);

        setContentView(R.layout.activity_film_data);

        Intent intent = getIntent();

         i = intent.getExtras().getLong("Peli");


        Film f =  FilmDataSource.films.get((int)i);

        cargarDatos(f);
    }

    private void cargarDatos(Film f)
    {
        nombre = f.title;
        String director = f.director;

        int anyo = f.year;
        String strAnyo = String.valueOf(anyo);

        TextView textAnyo = (TextView) findViewById(R.id.estreno);
        textAnyo.setText(strAnyo);

        int formato = f.format;
        TextView txtFormato = (TextView) findViewById(R.id.formato);
        switch (formato)
        {
            case 0:
                txtFormato.setText("Blu-Ray");
                break;
            case 1:
                txtFormato.setText("DVD");
                break;
            case 2:
                txtFormato.setText("Digital");
                break;

        }

        int genero = f.genre;
        TextView txtGenero = (TextView) findViewById(R.id.genero);
        switch (genero)
        {
            case 0:
                txtGenero.setText("Horror");
                break;
            case 1:
                txtGenero.setText("Comedia");
                break;
            case 2:
                txtGenero.setText("Drama");
                break;
            case 3:
                txtGenero.setText("Sci-Fi");
                break;
            case 4:
                txtGenero.setText("Accion");
                break;
        }

        String comentarios = f.comments;

        TextView txtComentarios = (TextView) findViewById(R.id.usuario);
        txtComentarios.setText(comentarios);

        int IdImg = f.imageResId;

        ImageView img = (ImageView) findViewById(R.id.imagen);
        img.setImageResource(IdImg);

        TextView txtNombre = (TextView) findViewById(R.id.lblPeli);
        txtNombre.setText(nombre);

        TextView txtDirector = (TextView) findViewById(R.id.director);
        txtDirector.setText(director);

    }

    public void btnVolvInicio(View view)
    {
        Intent intent2 = new Intent (view.getContext(), FilmListActivity.class);
        startActivityForResult(intent2, 0);
    }

    public void editPeli(View view)
    {
        Intent intent = new Intent(FilmDataActivity.this, FilmEditActivity.class);
        intent.putExtra("Peli", i);
        startActivity(intent);
    }


    public void onBackPressed() {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

            if(resultCode == Activity.RESULT_OK){
                Toast toast1 = Toast.makeText(getApplicationContext(),
                                "✅", Toast.LENGTH_SHORT);

                toast1.show();
            }
            if (resultCode == Activity.RESULT_CANCELED) {
                Toast toast1 = Toast.makeText(getApplicationContext(),
                        "❌", Toast.LENGTH_SHORT);

                toast1.show();
            }

    }

}